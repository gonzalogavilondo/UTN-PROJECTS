package distribuidora.liquidacion.empleado;

import com.google.gson.annotations.Expose;
import distribuidora.liquidacion.configuracion.Configuracion;

public class Vendedor extends Empleado implements Supervisable {
    @Expose
    private double ventas;
    @Expose(serialize = false, deserialize = false)
    private Supervisor supervisor;

    public Vendedor(String legajo, String nombre) {
        super(legajo, nombre, Configuracion.BASE_VENDEDOR.getMonto());
    }

    public Vendedor(String legajo, String nombre, double ventas, double sueldo) {
        super(legajo, nombre, sueldo);
        this.ventas = ventas;
    }

    public double getVentas() {
        return ventas;
    }

    public void setVentas(double ventas) {
        this.ventas = ventas;
        calcularSueldo();
        supervisor.calcularSueldo();
    }

    public Supervisor getSupervisor() {
        return supervisor;
    }

    @Override
    protected void calcularSueldo() {
        float comision;
        if (this.ventas <= Configuracion.TECHO_VENDEDORES_PRIMER_NIVEL.getMonto())
            comision = Configuracion.COMISION_VENDEDORES_PRIMER_NIVEL.getMonto();
        else if (this.ventas <= Configuracion.TECHO_VENDEDORES_SEGUNDO_NIVEL.getMonto())
            comision = Configuracion.COMISION_VENDEDORES_SEGUNDO_NIVEL.getMonto();
        else comision = Configuracion.COMISION_VENDEDORES_TERCER_NIVEL.getMonto();

        double sueldo = Configuracion.BASE_VENDEDOR.getMonto() + (this.ventas * comision);
        super.setSueldo(sueldo);
    }

    @Override
    public boolean isVendedor() {
        return true;
    }

    @Override
    public boolean isRepartidor() {
        return false;
    }

    @Override
    public boolean isSupervisor() {
        return false;
    }

    @Override
    public boolean isAdministrador() {
        return false;
    }

    @Override
    public boolean isSupervisable() {
        return true;
    }

    @Override
    public String toString() {
        return String.format("""
                                     ----------------------
                                     Vendedor %s
                                     Legajo %s
                                     Ventas mensuales: $%.2f
                                     Sueldo mensual: $%.2f
                                     ----------------------
                                     """, super.getNombre(), super.getLegajo(), this.ventas, super.getSueldo());
    }

    @Override
    public void supervisar(Supervisor supervisor) {
        this.supervisor = supervisor;
        this.supervisor.addVendedor(this);
    }

    @Override
    public void liberar() {
        this.supervisor.removeVendedor(this);
        this.supervisor = null;
    }
}
