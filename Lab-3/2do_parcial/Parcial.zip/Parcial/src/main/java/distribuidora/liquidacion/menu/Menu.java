package distribuidora.liquidacion.menu;

import distribuidora.liquidacion.excepciones.EmpleadoInexistenteException;

public interface Menu {
    void ejecutarMenuPrincipal();

    void ejecutarBuscarEmpleado() throws EmpleadoInexistenteException;

    void ejecutarListarEmpleados();
}
