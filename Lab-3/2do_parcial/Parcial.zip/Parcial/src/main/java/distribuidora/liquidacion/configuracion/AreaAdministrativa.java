package distribuidora.liquidacion.configuracion;

import org.apache.logging.log4j.util.Strings;

import java.io.Serializable;

public enum AreaAdministrativa implements Serializable {
    VENTAS, LOGISTICA, FINANZAS;

    public static AreaAdministrativa value(String name) {
        if (Strings.isBlank(name)) return null;
        return valueOf(name);
    }
}
