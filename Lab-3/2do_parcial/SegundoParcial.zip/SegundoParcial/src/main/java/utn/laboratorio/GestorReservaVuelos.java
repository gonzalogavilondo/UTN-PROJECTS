package utn.laboratorio;

import utn.laboratorio.entidades.Reserva;
import utn.laboratorio.entidades.Vuelo;
import utn.laboratorio.enumeraciones.Destino;
import utn.laboratorio.enumeraciones.EstadoReserva;
import utn.laboratorio.sistema.Sistema;

import javax.swing.*;
import java.util.List;

public class GestorReservaVuelos {
    private final Sistema sistema = Sistema.instancia();
    private final JFrame frame;
    private JPanel panelPrincipal;
    private JRadioButton botonSoloIda;
    private JRadioButton botonIdaVuelta;
    private JComboBox<Destino> comboOrigen;
    private JComboBox<Destino> comboDestino;
    private JButton botonBuscarVuelos;
    private JSplitPane panelFiltrados;
    private JTextField inputCodigoReserva;
    private JButton botonBuscarReserva;
    private JLabel codigoReserva;
    private JLabel origen;
    private JLabel destino;
    private JComboBox<EstadoReserva> comboEstadoReserva;
    private JLabel pasajero;
    private JLabel horarioSalida;
    private JLabel horarioLlegada;
    private JPanel panelDetalleReserva;

    public GestorReservaVuelos() {
        frame = new JFrame("Reserva de vuelos");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setExtendedState(JFrame.MAXIMIZED_BOTH);
        frame.setContentPane(panelPrincipal);
        frame.pack();
        frame.setVisible(true);
        init();
    }

    public static void main(String[] args) {
        GestorReservaVuelos gestorReservaVuelos = new GestorReservaVuelos();
    }

    private void init() {
        botonBuscarVuelos.addActionListener(e -> {
            panelFiltrados.setRightComponent(null);

            Destino origen = (Destino) comboOrigen.getSelectedItem();
            Destino destino = (Destino) comboDestino.getSelectedItem();

            JOptionPane.showMessageDialog(null, STR."Buscando vuelos de\n \{origen} \n\na\n \{destino}", "Buscando vuelos",
                                          JOptionPane.INFORMATION_MESSAGE);

            /*
                TODO 9: Obtener la lista de vuelos filtrados por destino y mostrarlos en la lista de vuelos.
                 Llamar al método de la clase Sistema que filtra los vuelos por destino.
                 Llamar al método mostrarVuelos para mostrar los vuelos en la lista.
                 (3 puntos)
             */
        });

        botonBuscarReserva.addActionListener(e -> {
            String codigoReserva = inputCodigoReserva.getText();

            JOptionPane.showMessageDialog(null, STR."Buscando reserva con código \{codigoReserva}", "Buscando reserva",
                                          JOptionPane.INFORMATION_MESSAGE);

            /*
                TODO 14: Obtener la reserva por código y mostrarla en el panel de detalle de reserva.
                 Llamar al método de la clase Sistema que busca la reserva por código.
                 Llamar al método mostrarReserva para mostrar la reserva en el panel.
                 (3 puntos)
             */
        });
    }

    private void mostrarVuelos(List<Vuelo> vuelos) {
        JList<Vuelo> listaVuelos = new JList<>(vuelos.toArray(new Vuelo[0]));
        listaVuelos.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        listaVuelos.setLayoutOrientation(JList.VERTICAL);

        listaVuelos.addListSelectionListener(e -> {
            Vuelo vueloSeleccionado = listaVuelos.getSelectedValue();
            DetalleVuelo detalleVuelo = new DetalleVuelo(vueloSeleccionado);
            panelFiltrados.setRightComponent(detalleVuelo.getContentPane());
        });

        panelFiltrados.setLeftComponent(new JScrollPane(listaVuelos));
    }

    private void mostrarReserva(Reserva reserva) {
        /*
            TODO 15: Mostrar la reserva en el panel de detalle de reserva.
             Mostrar el código de la reserva, origen, destino, horario de salida, horario de llegada, pasajero y estado de la reserva.
             (3 puntos)
         */
        panelDetalleReserva.setVisible(true);
    }

    private void createUIComponents() {
        comboDestino = new JComboBox<>(Destino.values());
        comboOrigen = new JComboBox<>(Destino.values());
        comboEstadoReserva = new JComboBox<>(EstadoReserva.values());
        panelFiltrados = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT);
    }
}
