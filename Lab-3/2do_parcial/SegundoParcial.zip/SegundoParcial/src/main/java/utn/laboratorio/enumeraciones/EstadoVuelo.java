package utn.laboratorio.enumeraciones;

public enum EstadoVuelo {
    PROGRAMADO, RETRASADO, CANCELADO, DESPEGADO
}
