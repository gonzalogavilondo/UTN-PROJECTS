package distribuidora.liquidacion.empleado;

import com.google.gson.annotations.Expose;

import java.io.Serializable;
import java.util.Objects;

public abstract class Empleado implements Serializable {
    @Expose
    private final String legajo;
    @Expose
    private String nombre;
    @Expose
    private double sueldo;

    public Empleado(String legajo, String nombre, double sueldo) {
        this.legajo = legajo;
        this.nombre = nombre;
        this.sueldo = sueldo;
    }

    public String getLegajo() {
        return legajo;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public double getSueldo() {
        return sueldo;
    }

    protected void setSueldo(double sueldo) {
        this.sueldo = sueldo;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if ((o instanceof Vendedor vendedor)) return Objects.equals(legajo, vendedor.getLegajo());
        else if ((o instanceof Repartidor repartidor)) return Objects.equals(legajo, repartidor.getLegajo());
        else if ((o instanceof Administrador administrador)) return Objects.equals(legajo, administrador.getLegajo());
        else if ((o instanceof Supervisor supervisor)) return Objects.equals(legajo, supervisor.getLegajo());
        else return Objects.equals(legajo, o);
    }

    @Override
    public int hashCode() {
        return Objects.hash(legajo);
    }

    protected abstract void calcularSueldo();

    public abstract boolean isVendedor();

    public abstract boolean isRepartidor();

    public abstract boolean isSupervisor();

    public abstract boolean isAdministrador();

    public abstract boolean isSupervisable();
}
