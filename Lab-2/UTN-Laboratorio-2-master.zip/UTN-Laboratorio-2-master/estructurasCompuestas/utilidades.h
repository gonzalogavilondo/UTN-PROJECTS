#ifndef UTILIDADES_H_INCLUDED
#define UTILIDADES_H_INCLUDED

#include <stdlib.h>
#include <stdio.h>

int randomRango(int min, int max);
void replicante(char c, int n);

#endif // UTILIDADES_H_INCLUDED
