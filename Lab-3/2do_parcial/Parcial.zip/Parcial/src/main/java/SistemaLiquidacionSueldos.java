import distribuidora.liquidacion.empleado.*;
import distribuidora.liquidacion.excepciones.EmpleadoInexistenteException;
import distribuidora.liquidacion.gestor.GestorEmpleados;
import distribuidora.liquidacion.impresora.Impresora;
import distribuidora.liquidacion.impresora.ImpresoraEXCEL;
import distribuidora.liquidacion.impresora.ImpresoraJSON;
import distribuidora.liquidacion.menu.Menu;
import render.RenderEmpleado;

import javax.swing.*;
import java.awt.*;
import java.io.IOException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

@SuppressWarnings("BoundFieldAssignment")
public class SistemaLiquidacionSueldos implements Menu {

    private static final Logger logger = Logger.getLogger(SistemaLiquidacionSueldos.class.getName());
    private final GestorEmpleados gestorEmpleados = new GestorEmpleados(false);
    private final JFrame frame;
    private Empleado empleado;
    private JPanel contenedor;
    private JButton buttonBuscarEmpleado;
    private JButton buttonListarEmpleados;
    private JButton buttonReportes;
    private JTabbedPane panelTodos;
    private JList<Empleado> listaRepartidores;
    private JList<Empleado> listaVendedores;
    private JList<Empleado> listaAdministradores;
    private JList<Empleado> listaSupervisores;
    private JPanel panelEmpleado;
    private JButton buttonCargarDatos;
    private JButton buttonPrueba;

    public SistemaLiquidacionSueldos() {
        this.frame = new JFrame("Sistema de liquidación de sueldos");
        this.frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.frame.setLocationRelativeTo(null); // Centrar
        this.frame.setExtendedState(Frame.MAXIMIZED_BOTH); // Maximizar la ventana
    }

    public static void main(String[] args) {
        SistemaLiquidacionSueldos sistema = new SistemaLiquidacionSueldos();
        sistema.ejecutarMenuPrincipal();
    }

    @Override
    public void ejecutarMenuPrincipal() {
        this.buttonCargarDatos.addActionListener(e -> {
            try {
                String path = JOptionPane.showInputDialog(this.contenedor, "Ubicación del archivo a cargar", "Cargar datos",
                                                          JOptionPane.QUESTION_MESSAGE);
                Impresora impresora = new ImpresoraJSON();
                List<Empleado> empleados = impresora.leer(path);
                gestorEmpleados.cargarEmpleados(empleados);
                mostrarResultado("Se cargaron los datos correctamente");
            } catch (IOException exception) {
                ejecutarError(exception);
            }
        });

        this.buttonBuscarEmpleado.addActionListener(e -> {
            try {
                ejecutarBuscarEmpleado();
            } catch (EmpleadoInexistenteException exception) {
                ejecutarError(exception);
            }
        });

        this.buttonListarEmpleados.addActionListener(e -> {
            ejecutarListarEmpleados();
        });

        this.buttonReportes.addActionListener(e -> {
            Impresora impresora = new ImpresoraJSON();
            try {
                String nombre = impresora.imprimir(gestorEmpleados.empleados());
                mostrarResultado(STR."Se generó el reporte \{nombre}");
            } catch (IOException exception) {
                ejecutarError(exception);
            }
        });

        this.frame.setContentPane(contenedor);
        this.frame.pack();
        this.frame.setVisible(true);
    }

    @Override
    public void ejecutarBuscarEmpleado() throws EmpleadoInexistenteException {
        this.panelTodos.setVisible(false);
        this.panelEmpleado.setVisible(true);

        this.empleado = buscarEmpleado();
        ((RenderEmpleado) this.panelEmpleado).mostrarDetalleEmpleado(this.empleado);
    }

    @Override
    public void ejecutarListarEmpleados() {
        this.panelEmpleado.setVisible(false);
        this.panelTodos.setVisible(true);

        this.listaRepartidores.setCellRenderer(new RenderEmpleado());
        this.listaRepartidores.setListData(gestorEmpleados.filtrarRepartidores().toArray(new Repartidor[0]));

        this.listaVendedores.setCellRenderer(new RenderEmpleado());
        this.listaVendedores.setListData(gestorEmpleados.filtrarVendedores().toArray(new Vendedor[0]));

        this.listaAdministradores.setCellRenderer(new RenderEmpleado());
        this.listaAdministradores.setListData(gestorEmpleados.filtrarAdministradores().toArray(new Administrador[0]));

        this.listaSupervisores.setCellRenderer(new RenderEmpleado());
        this.listaSupervisores.setListData(gestorEmpleados.filtrarSupervisores().toArray(new Supervisor[0]));
    }

    private Empleado buscarEmpleado() throws EmpleadoInexistenteException {
        // Mostrar un cuadro de diálogo para ingresar el labelLegajo del empleado
        String legajo = JOptionPane.showInputDialog(this.contenedor.getParent(), "Legajo:", "Buscar empleado",
                                                    JOptionPane.QUESTION_MESSAGE);

        return gestorEmpleados.buscarEmpleado(legajo);
    }

    private void ejecutarError(Exception exception) {
        logger.log(Level.SEVERE, exception.getMessage(), exception);
        JOptionPane.showMessageDialog(this.contenedor, exception.getMessage());
    }

    private void mostrarResultado(Object object) {
        JOptionPane.showMessageDialog(this.frame, object, "Resultado", JOptionPane.INFORMATION_MESSAGE);
    }

    private void createUIComponents() {
        this.panelEmpleado = new RenderEmpleado();
    }
}
