package utn.laboratorio.sistema;

/*
    TODO 6: Implementar la clase Gestor que permita agregar, buscar, filtrar y listar elementos de tipo T.
     T debe implementar las interfaces Buscable y Filtrable, además de ser Comparable.
     El gestor debe almacenar los elementos en un TreeSet.
     Pista: Utilizar el método matches de la interfaz Buscable y el método filter de la interfaz Filtrable.
     Pista 2: Para limitar el tipo T a elementos que implementen las interfaces Buscable, Filtrable y Comparable, se puede utilizar la
     cláusula & en la definición de la clase.
     Por ejemplo: public class Gestor<T extends Interfaz1 & Interfaz2> { }
     (15 puntos)
 */
public class Gestor {
}
