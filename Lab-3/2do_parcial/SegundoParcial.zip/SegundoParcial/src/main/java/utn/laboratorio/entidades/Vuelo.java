package utn.laboratorio.entidades;

/*
    TODO 4: Implementar la clase Vuelo que cumpla con las interfaces Buscable<String>, Comparable<Vuelo> y
     Filtrable<Destino>. La clase debe tener los siguientes atributos:
     - codigoVuelo: representa el código del vuelo.
     - origen: representa el origen del vuelo.
     - destino: representa el destino del vuelo.
     - horarioSalida: representa el horario de salida del vuelo.
     - horarioLlegada: representa el horario de llegada del vuelo.
     - estado: representa el estado del vuelo.
     La clase debe tener los siguientes métodos:
     - Método retrasado que permite cambiar el estado del vuelo a retrasado y modificar el horario de salida.
     - Método cancelado que permite cambiar el estado del vuelo a cancelado.
     - Método despegado que permite cambiar el estado del vuelo a despegado.
     El vuelo se crea por defecto en estado programado.
     Los vuelos se pueden buscar por código de vuelo.
     Los vuelos se pueden filtrar por destino.
     Los vuelos se pueden comparar por destino.
     El formato del horario de salida y de llegada debe ser dd/MM/yyyy HH:mm. Pista: Usar DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm").
     (10 puntos)
 */
public class Vuelo {
}
