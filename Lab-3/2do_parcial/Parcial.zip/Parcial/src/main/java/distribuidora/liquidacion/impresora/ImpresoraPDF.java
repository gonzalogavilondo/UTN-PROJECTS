package distribuidora.liquidacion.impresora;

import com.itextpdf.kernel.pdf.PdfDocument;
import com.itextpdf.kernel.pdf.PdfWriter;
import com.itextpdf.layout.Document;
import com.itextpdf.layout.element.Paragraph;
import com.itextpdf.layout.element.Table;
import com.itextpdf.layout.properties.UnitValue;
import distribuidora.liquidacion.empleado.Empleado;
import distribuidora.liquidacion.empleado.Vendedor;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.List;
import java.util.logging.Level;

public class ImpresoraPDF extends Impresora {

    @Override
    public String imprimir(List<Empleado> empleados) throws IOException {
        return imprimir(empleados, DEFAULT_PATH);
    }

    @Override
    public String imprimir(List<Empleado> empleados, String path) throws IOException {
        for (Empleado empleado : empleados) {
            String name = STR."\{path}/\{empleado.getNombre()}\{DEFAULT_FILENAME}\{PDF_EXTENSION}";
            logger.log(Level.INFO, name);

            try {
                // Inicializar PDF writer y document
                PdfWriter writer = new PdfWriter(name);
                PdfDocument pdf = new PdfDocument(writer);
                Document document = new Document(pdf);

                // Añadir título
                document.add(new Paragraph("Recibo de Sueldo").setBold().setFontSize(14));

                // Añadir una tabla para detalles del empleado
                float[] columnWidths = {1, 5};
                Table table = new Table(UnitValue.createPercentArray(columnWidths));
                table.addCell("Legajo");
                table.addCell(empleado.getLegajo());
                table.addCell("Nombre");
                table.addCell(empleado.getNombre());
                table.addCell("Puesto");
                table.addCell(empleado.getClass().getName());
                document.add(table);

                // Añadir una sección para los detalles de pago
                document.add(new Paragraph("\nDetalles de Pago:").setBold().setFontSize(12));
                Table paymentDetails = new Table(UnitValue.createPercentArray(new float[]{3, 1, 2}));
                paymentDetails.addCell("Concepto");
                paymentDetails.addCell("Adicional");
                paymentDetails.addCell("Salario Base");
                paymentDetails.addCell("Concepto");
                if (empleado.isVendedor()) paymentDetails.addCell(String.valueOf(((Vendedor) empleado).getVentas()));
                paymentDetails.addCell("Bono");
                paymentDetails.addCell("0");
                paymentDetails.addCell("$500");
                document.add(paymentDetails);

                // Cerrar el documento
                document.close();
            } catch (FileNotFoundException e) {
                logger.log(Level.SEVERE, e.getMessage(), e);
            }
        }
        return path;
    }

    @Override
    public List<Empleado> leer(String path) throws IOException {
        return null;
    }
}
