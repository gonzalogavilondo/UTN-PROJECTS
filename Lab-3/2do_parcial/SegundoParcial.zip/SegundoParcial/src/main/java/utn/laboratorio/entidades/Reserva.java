package utn.laboratorio.entidades;

/*
    TODO 5: Implementar la clase Reserva que cumpla con las interfaces Buscable<String>, Comparable<Reserva> y
     Filtrable<Pasajero>. La clase debe tener los siguientes atributos:
     - idReserva: representa el identificador de la reserva.
     - pasajero: representa el pasajero que realiza la reserva.
     - vuelo: representa el vuelo que se reserva.
     - claseAsiento: representa la clase de asiento que se reserva.
     - estado: representa el estado de la reserva.
     La clase debe tener los siguientes métodos:
     - Método cambiarAsiento que permite cambiar la clase de asiento de la reserva.
     - Método cancelar que permite cambiar el estado de la reserva a cancelada.
     - Método confirmar que permite cambiar el estado de la reserva a confirmada.
     La reserva se crea por defecto en estado pendiente.
     El formato del id de reserva debe ser R{contador}{vuelo.getHorarioSalida().getNano()} donde contador es un número que se incrementa
     en 1 por cada reserva, comenzando en 0.
     Las reservas se pueden buscar por id de reserva.
     Las reservas se pueden filtrar por pasajero.
     Las reservas se pueden comparar por id de reserva.
     (10 puntos)
 */
public class Reserva {
}

