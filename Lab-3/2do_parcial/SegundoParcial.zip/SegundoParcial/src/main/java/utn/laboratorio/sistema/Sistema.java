package utn.laboratorio.sistema;

/*
    TODO 7: Implementar la clase Sistema.
     La clase Sistema debe contener los métodos necesarios para agregar, buscar y filtrar vuelos, pasajeros y reservas.
     Además, debe contener métodos para crear, confirmar, cancelar y cambiar la clase de un asiento de una reserva.
     Los elementos deben ser almacenados en instancias de la clase Gestor.
     El método que busca un pasajero debe lanzar una excepción si el pasaporte no existe.
     La excepción debe ser de tipo PasajeroNoEncontradoException e informar el pasaporte que no se encontró.
     (15 puntos)
 */
public class Sistema {
    private static Sistema instance;

    public Sistema() {
        /*
            TODO 8: Generar datos de prueba.
             Agregar 10 vuelos con distintos destinos y fechas de salida.
             Pista: Para generar fechas en el futuro, se pueden utilizar los métodos plusDays, plusWeeks y plusMonths de la clase
             LocalDateTime.
             Agregar 2 pasajeros con distintos nombres y pasaportes.
             Agregar una reserva para cada pasajero en un vuelo distinto.
             (2 puntos)
         */
    }

    public static synchronized Sistema instancia() {
        if (instance == null) {
            instance = new Sistema();
        }
        return instance;
    }
}
