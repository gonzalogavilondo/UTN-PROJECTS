package utn.laboratorio;

import utn.laboratorio.entidades.Pasajero;
import utn.laboratorio.entidades.Reserva;
import utn.laboratorio.entidades.Vuelo;
import utn.laboratorio.enumeraciones.ClaseAsiento;
import utn.laboratorio.enumeraciones.Destino;
import utn.laboratorio.sistema.Sistema;

import javax.swing.*;
import java.awt.*;
import java.awt.datatransfer.StringSelection;

public class DialogReservaVuelo extends JDialog {
    private final Sistema sistema = Sistema.instancia();
    private final Vuelo vuelo;
    private Pasajero pasajero;
    private ClaseAsiento claseAsiento = ClaseAsiento.ECONOMICA;
    private JPanel contentPane;
    private JButton botonReservar;
    private JButton botonCancelar;
    private JLabel numeroVuelo;
    private JComboBox<Destino> comboOrigen;
    private JComboBox<Destino> comboDestino;
    private JLabel horarioSalida;
    private JLabel horarioLlegada;
    private JTextField inputPasaporte;
    private JButton botonBuscar;
    private JLabel pasaporte;
    private JLabel nombreCompleto;
    private JComboBox<ClaseAsiento> comboClaseAsiento;

    public DialogReservaVuelo(Vuelo vuelo) {
        this.vuelo = vuelo;
        setContentPane(contentPane);
        setModal(true);
        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        setSize(screenSize.width, screenSize.height);
        getRootPane().setDefaultButton(botonReservar);
        init();
    }

    private void init() {
        /*
            TODO 11: Completar el método init.
             El método debe completar los campos del formulario con los datos del vuelo recibido como parámetro.
             Por ejemplo, el campo numeroVuelo debe mostrar el código del vuelo.
             numeroVuelo.setText(vuelo.getCodigoVuelo());
             Campos a completar: numeroVuelo, comboOrigen, comboDestino, horarioSalida, horarioLlegada.
             (3 puntos)
         */

        this.comboClaseAsiento.addItemListener(e -> {
            this.claseAsiento = (ClaseAsiento) comboClaseAsiento.getSelectedItem();
            habilitarBotonReserva();
        });

        this.botonBuscar.addActionListener(e -> {
            String pasaporte = this.inputPasaporte.getText();
            /*
                TODO 12: Completar la acción del botón Buscar.
                 El método debe buscar un pasajero en el sistema a partir del pasaporte ingresado.
                 Si el pasajero no existe, debe mostrar un mensaje de error.
                 Si el pasajero existe, debe completar los campos pasaporte y nombreCompleto con los datos del pasajero.
                 Pista: El mensaje de error se puede mostrar con JOptionPane.showMessageDialog
                 (10 puntos)
             */
            habilitarBotonReserva();
        });

        this.botonReservar.addActionListener(e -> {
            /*
                TODO 13: Completar la acción del botón Reservar.
                 El método debe crear una reserva en el sistema a partir de los datos ingresados en el formulario.
                 Si la reserva se crea correctamente, debe mostrar un mensaje con el código de la reserva y dar la opción de copiarlo al
                 portapapeles.
                 (3 puntos)
             */

            String mensaje = "Reserva realizada con éxito.\nCódigo de reserva: "; // Concatenar el código de la reserva generada
            Object[] options = {"Copiar", "Cerrar"};
            int option = JOptionPane.showOptionDialog(this, mensaje, "Reserva realizada", JOptionPane.DEFAULT_OPTION,
                                                      JOptionPane.INFORMATION_MESSAGE, null, options, options[0]);

            if (option == 0) {
                /*
                    TODO: Llamar al método copiarAlPortapapeles con el código de la reserva.
                     copiarAlPortapapeles(reserva.getIdReserva());
                 */
                dispose();
            }
        });

        this.botonCancelar.addActionListener(e -> dispose());
    }

    private void copiarAlPortapapeles(String texto) {
        Toolkit.getDefaultToolkit().getSystemClipboard().setContents(new StringSelection(texto), null);
    }

    private void habilitarBotonReserva() {
        this.botonReservar.setEnabled(claseAsiento != null && pasajero != null);
    }

    private void createUIComponents() {
        comboDestino = new JComboBox<>(Destino.values());
        comboOrigen = new JComboBox<>(Destino.values());
        comboClaseAsiento = new JComboBox<>(ClaseAsiento.values());
    }
}
