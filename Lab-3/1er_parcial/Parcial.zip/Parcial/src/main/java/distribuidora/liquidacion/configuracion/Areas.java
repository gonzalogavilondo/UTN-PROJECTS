package distribuidora.liquidacion.configuracion;

public enum Areas {
    VENTAS, LOGISTICA, FINANZAS
}
