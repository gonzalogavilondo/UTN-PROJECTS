package distribuidora.liquidacion.impresora;

import distribuidora.liquidacion.empleado.Empleado;

import java.io.File;
import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.TextStyle;
import java.util.List;
import java.util.Locale;
import java.util.logging.Logger;

public abstract class Impresora {
    public static final Logger logger = Logger.getLogger(Impresora.class.getName());
    public static final String DESKTOP_PATH = STR."\{System.getProperty("user.home")}\{File.separator}Desktop";
    public static final String DEFAULT_FOLDER = "Sistema Liquidacion Sueldo";
    public static final String DEFAULT_PATH = STR."\{DESKTOP_PATH}/\{DEFAULT_FOLDER}";
    public static final String EXCEL_EXTENSION = ".xls";
    public static final String PDF_EXTENSION = ".pdf";
    public static final String JSON_EXTENSION = ".json";
    public static final String TEMPLATE_PATH_RECIBO = "template/Recibo.pdf";
    private static final DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
    private static final Locale locale = new Locale("es", "ES");
    public static final String DEFAULT_FILENAME = STR."-\{getPeriodo()}";

    public static String getPeriodo() {
        return LocalDate.now().getMonth().getDisplayName(TextStyle.FULL, locale);
    }

    public static String getFecha() {
        return LocalDate.now().format(formatter);
    }

    public abstract String imprimir(List<Empleado> empleados) throws IOException;

    public abstract String imprimir(List<Empleado> empleados, String path) throws IOException;

    public abstract List<Empleado> leer(String path) throws IOException;
}
