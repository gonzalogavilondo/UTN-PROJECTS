package distribuidora.liquidacion.empleado;

import com.google.gson.annotations.Expose;
import distribuidora.liquidacion.configuracion.Configuracion;

public class Repartidor extends Empleado {
    @Expose
    private double kmRecorridos;

    public Repartidor(String legajo, String nombre) {
        super(legajo, nombre, Configuracion.BASE_REPARTIDOR.getMonto());
    }

    public Repartidor(String legajo, String nombre, double kmRecorridos, double sueldo) {
        super(legajo, nombre, sueldo);
        this.kmRecorridos = kmRecorridos;
    }

    public double getKmRecorridos() {
        return kmRecorridos;
    }

    public void setKmRecorridos(double kmRecorridos) {
        this.kmRecorridos = kmRecorridos;
        calcularSueldo();
    }

    @Override
    protected void calcularSueldo() {
        double sueldo = Configuracion.BASE_REPARTIDOR.getMonto() + (this.kmRecorridos * Configuracion.VIATICOS_REPARTIDORES.getMonto());
        super.setSueldo(sueldo);
    }

    @Override
    public boolean isVendedor() {
        return false;
    }

    @Override
    public boolean isRepartidor() {
        return true;
    }

    @Override
    public boolean isSupervisor() {
        return false;
    }

    @Override
    public boolean isAdministrador() {
        return false;
    }

    @Override
    public boolean isSupervisable() {
        return false;
    }

    @Override
    public String toString() {
        return String.format("""
                                     ----------------------
                                     Repartidor %s
                                     Legajo %s
                                     Km recorridos: %.2f
                                     Sueldo mensual: $%.2f
                                     ----------------------
                                     """, super.getNombre(), super.getLegajo(), this.kmRecorridos, super.getSueldo());
    }
}
