package utn.laboratorio.entidades;

/*
    TODO 3: Implementar la clase Pasajero que cumpla con las interfaces Buscable<String>, Comparable<Pasajero> y
     Filtrable<String>. La clase debe tener los siguientes atributos:
     - pasaporte: representa el número de pasaporte del pasajero. Por ejemplo: AAA123456.
     - nombre: representa el nombre completo del pasajero.
     Los pasaportes y nombres deben ser almacenados en mayúsculas.
     Dos pasajeros son iguales si tienen el mismo pasaporte.
     Los pasajeros se pueden buscar por pasaporte.
     Los pasajeros se pueden filtrar por nombre.
     Los pasajeros se pueden comparar por nombre.
     (10 puntos)
 */
public class Pasajero {
}
