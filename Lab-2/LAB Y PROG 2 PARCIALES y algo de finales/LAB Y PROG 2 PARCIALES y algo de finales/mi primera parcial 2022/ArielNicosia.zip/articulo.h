#ifndef ARTICULO_H_INCLUDED
#define ARTICULO_H_INCLUDED
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

typedef struct{
    int id;
    int codigo;
    int rubro; /// 1 - Televisores / 2 - Lavarropas / 3 - Cocinas / 4 - Calefactores
    char marca[30];
    char modelo[30];
    float precio;
} stArticulo;


typedef struct nodoD{
 stArticulo datos;
 nodoD *siguiente;
 nodoD *anterior;
}nodoD;


typedef struct Fila{
    stArticulo datos;
    Fila *principio;
    Fila *fin;
}Fila;



stArticulo cargarUnArticulo();
void strRubro(int rubro,char strR[30]);
void mostrarUnArticulo(stArticulo a);






/////////////1///////////
nodoD *creaNodoD(stArticulo datos);
nodoD *iniciaListaD();
nodoD * agregarEnOrden(nodoD * listaD, nodoD * nuevoNodo) ;
nodoD *cargaListaD(nodoD *listaD, char nombreA[20]);
nodoD * agregarEnOrden(nodoD * lista, nodoD * nuevoNodo) {

nodoD *agregarPpio(nodoD *lista, nodoD *nuevoNodo)

///////////////2/////////
precioRecursivo(nodoD * lista,int rubro,char marca[20]);

/////////3/////

stArticulo menorPrecio(nodoD *litaD);

/////////4/////
Pila listaAPila(nodoD *lista, Pila *pila,int rubro);

/////////5///////////////
int cuentaPila(Pila *pila,char marca[20]);
//////////6//////
void *pilaAFila(nodoD *pila,fila **Fila,float precio);

/////////
#endif // ARTICULO_H_INCLUDED
