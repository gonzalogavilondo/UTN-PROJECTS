package distribuidora.liquidacion.excepciones;

public class ValorNumericoIncorrectoException extends Exception {
    private Object value;

    public ValorNumericoIncorrectoException(Object value) {
        super(STR."No se puede procesar el valor \{value}");
    }

    public Object getValue() {
        return value;
    }
}
