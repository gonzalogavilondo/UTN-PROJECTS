package utn.laboratorio.enumeraciones;

public enum ClaseAsiento {
    ECONOMICA, NEGOCIOS, PRIMERA
}
