package utn.laboratorio.enumeraciones;

public enum TipoVuelo {
    NACIONAL, INTERNACIONAL
}
