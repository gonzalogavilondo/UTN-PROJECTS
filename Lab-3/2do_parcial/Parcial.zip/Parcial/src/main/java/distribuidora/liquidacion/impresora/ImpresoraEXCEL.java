package distribuidora.liquidacion.impresora;

import distribuidora.liquidacion.configuracion.AreaAdministrativa;
import distribuidora.liquidacion.empleado.*;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.FileOutputStream;
import java.io.IOException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;

public class ImpresoraEXCEL extends Impresora {

    private final int COLUMN_TIPO_INDEX = 0;
    private final int COLUMN_LEGAJO_INDEX = 1;
    private final int COLUMN_NOMBRE_INDEX = 2;
    private final int COLUMN_ADICIONAL_INDEX = 3;
    private final int COLUMN_SUELDO_INDEX = 4;
    private final int COLUMN_AREA_INDEX = 5;
    private final int COLUMN_TOTAL = 6;

    @Override
    public String imprimir(List<Empleado> empleados) throws IOException {
        return imprimir(empleados, DEFAULT_PATH);
    }

    @Override
    public String imprimir(List<Empleado> empleados, String path) throws IOException {
        String name = STR."\{path}/Datos\{DEFAULT_FILENAME}\{EXCEL_EXTENSION}";
        logger.log(Level.INFO, name);

        // Crear un libro de trabajo de Excel
        try (Workbook workbook = new XSSFWorkbook()) {
            // Crear una hoja
            Sheet sheet = workbook.createSheet(LocalDate.now().getMonth().name());

            // Crear la fila de encabezado
            Row headerRow = sheet.createRow(0);
            headerRow.createCell(COLUMN_TIPO_INDEX).setCellValue("Tipo");
            headerRow.createCell(COLUMN_LEGAJO_INDEX).setCellValue("Legajo");
            headerRow.createCell(COLUMN_NOMBRE_INDEX).setCellValue("Nombre");
            headerRow.createCell(COLUMN_ADICIONAL_INDEX).setCellValue("Adicional");
            headerRow.createCell(COLUMN_SUELDO_INDEX).setCellValue("Sueldo");

            // Llenar la hoja con datos de empleados
            int rowNum = 1;
            for (Empleado empleado : empleados) {
                Row row = sheet.createRow(rowNum++);

                row.createCell(COLUMN_TIPO_INDEX).setCellValue(empleado.getClass().getSimpleName());
                row.createCell(COLUMN_LEGAJO_INDEX).setCellValue(empleado.getLegajo());
                row.createCell(COLUMN_NOMBRE_INDEX).setCellValue(empleado.getNombre());

                if (empleado.isVendedor()) row.createCell(COLUMN_ADICIONAL_INDEX).setCellValue(((Vendedor) empleado).getVentas());
                else if (empleado.isRepartidor())
                    row.createCell(COLUMN_ADICIONAL_INDEX).setCellValue(((Repartidor) empleado).getKmRecorridos());
                else row.createCell(COLUMN_ADICIONAL_INDEX).setCellValue(0);

                row.createCell(COLUMN_SUELDO_INDEX).setCellValue(empleado.getSueldo());

                if (empleado.isAdministrador())
                    row.createCell(COLUMN_AREA_INDEX).setCellValue(((Administrador) empleado).getArea().toString());
                else row.createCell(COLUMN_AREA_INDEX).setCellValue("");
            }

            // Ajustar el tamaño de todas las columnas para ajustarse al contenido
            for (int i = 0; i < COLUMN_TOTAL; i++) {
                sheet.autoSizeColumn(i);
            }

            // Escribir el archivo de salida
            try (FileOutputStream fileOut = new FileOutputStream(name)) {
                workbook.write(fileOut);
            }
        } catch (IOException e) {
            logger.log(Level.SEVERE, STR."Error al generar el archivo \{name}", e);
            throw e;
        }
        return name;
    }

    @Override
    public List<Empleado> leer(String path) throws IOException {
        List<Empleado> empleados = new ArrayList<>();
        try (Workbook workbook = new XSSFWorkbook(path)) {
            // Obtener la hoja
            Sheet sheet = workbook.getSheetAt(0);

            // Leer los datos de la hoja
            for (Row row : sheet) {
                // Ignorar la fila de encabezado
                if (row.getRowNum() == 0) continue;

                // Leer los datos de la fila
                String tipo = row.getCell(COLUMN_TIPO_INDEX).getStringCellValue();
                String legajo = row.getCell(COLUMN_LEGAJO_INDEX).getStringCellValue();
                String nombre = row.getCell(COLUMN_NOMBRE_INDEX).getStringCellValue();
                double adicional = row.getCell(COLUMN_ADICIONAL_INDEX).getNumericCellValue();
                double sueldo = row.getCell(COLUMN_SUELDO_INDEX).getNumericCellValue();
                AreaAdministrativa area = AreaAdministrativa.value(row.getCell(COLUMN_AREA_INDEX).getStringCellValue());

                // Crear un empleado con los datos leídos
                switch (tipo) {
                    case "Vendedor":
                        empleados.add(new Vendedor(legajo, nombre, adicional, sueldo));
                    case "Repartidor":
                        empleados.add(new Repartidor(legajo, nombre, sueldo, adicional));
                    case "Supervisor":
                        empleados.add(new Supervisor(legajo, nombre, sueldo));
                    case "Administrador":
                        empleados.add(new Administrador(legajo, nombre, area, sueldo));
                }
            }
            return empleados;
        } catch (IOException e) {
            logger.log(Level.SEVERE, STR."Error al leer el archivo \{path}", e);
            throw e;
        }
    }
}
