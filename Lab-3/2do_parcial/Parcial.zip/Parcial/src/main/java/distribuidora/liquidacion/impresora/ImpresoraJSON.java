package distribuidora.liquidacion.impresora;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import com.google.gson.reflect.TypeToken;
import distribuidora.liquidacion.empleado.*;

import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.stream.Collectors;

public class ImpresoraJSON extends Impresora {
    private Gson gson() {
        return new GsonBuilder().excludeFieldsWithoutExposeAnnotation().create();
    }

    @Override
    public String imprimir(List<Empleado> empleados) throws IOException {
        return imprimir(empleados, DEFAULT_PATH);
    }

    @Override
    public String imprimir(List<Empleado> empleados, String path) throws IOException {
        Gson gson = gson();

        String name = STR."\{path}/Datos\{DEFAULT_FILENAME}\{JSON_EXTENSION}";
        logger.log(Level.INFO, name);

        JsonObject jsonObject = new JsonObject();
        jsonObject.add("vendedores", gson.toJsonTree(empleados.stream().filter(Empleado::isVendedor).collect(Collectors.toList())));
        jsonObject.add("repartidores", gson.toJsonTree(empleados.stream().filter(Empleado::isRepartidor).collect(Collectors.toList())));
        jsonObject.add("supervisores", gson.toJsonTree(empleados.stream().filter(Empleado::isSupervisor).collect(Collectors.toList())));
        jsonObject.add("administradores",
                       gson.toJsonTree(empleados.stream().filter(Empleado::isAdministrador).collect(Collectors.toList())));

        try (FileWriter writer = new FileWriter(name)) {
            gson.toJson(jsonObject, writer);
            return name;
        } catch (IOException e) {
            logger.log(Level.SEVERE, STR."Error al generar el archivo \{name}", e);
            throw e;
        }
    }

    @Override
    public List<Empleado> leer(String path) throws IOException {
        try {
            Gson gson = gson();
            String json = Files.readString(Paths.get(path));
            JsonObject jsonObject = gson.fromJson(json, JsonObject.class);

            List<Empleado> vendedores = gson.fromJson(jsonObject.get("vendedores"), new TypeToken<List<Vendedor>>() {
            }.getType());
            List<Empleado> repartidores = gson.fromJson(jsonObject.get("repartidores"), new TypeToken<List<Repartidor>>() {
            }.getType());
            List<Empleado> supervisores = gson.fromJson(jsonObject.get("supervisores"), new TypeToken<List<Supervisor>>() {
            }.getType());
            List<Empleado> administradores = gson.fromJson(jsonObject.get("administradores"), new TypeToken<List<Administrador>>() {
            }.getType());

            List<Empleado> empleados = new ArrayList<>();
            empleados.addAll(vendedores);
            empleados.addAll(repartidores);
            empleados.addAll(supervisores);
            empleados.addAll(administradores);

            return empleados;
        } catch (IOException e) {
            logger.log(Level.SEVERE, STR."Error al leer el archivo \{path}", e);
            throw e;
        }
    }
}
