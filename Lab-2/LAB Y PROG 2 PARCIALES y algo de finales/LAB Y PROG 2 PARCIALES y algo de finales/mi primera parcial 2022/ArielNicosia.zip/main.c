#ifndef ARTICULO_H_INCLUDED
#define ARTICULO_H_INCLUDED
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "articulo.h"


/// no se por que pero me tira errores por todos lados solo al agregar el .c y .h
//cuando creo el struct de nodo me tira error como que no exite y en mi casa lo hago igual y nome tira error
//como tengo error al compilar la verdad no se que cosas estan bien bien, y donde me falta un ; o cerrar algun parentesis
// es una lastima porque si podia ir compilando el codigo me iba a quedar mas claro y limpio
// escribi todo el codigo poder probar nada, asi que hay muchas cosas que seguro se me pasaron de largo que capaz son . y puse ->


int main()
{
   nodoD *listaD;
   fila *Fila;
   int rubro;
   float precio;
   char nombreRubro[20];
   char nombreMarca[20];
   char nombreA[]="articulos.dat" ;
   Pila pial=iniciaPila();

   Fila=iniciaFila(); //inicio con NULL
   listaD=iniciaListaD();//inicio con NULL
   ///////////1
   listaD=cargaListaD(lista,nombreA);// cargo la lista doble con los datos del archivo bin
   //////////2
   printf("\n ingrese un rubro  1 - Televisores / 2 - Lavarropas / 3 - Cocinas / 4 - Calefactores\n");
   scanf("%i",&rubro);
   strRubro(rubro,nombreRubro); ///pido el rubro y lo asigno a nombreRubro
   printf("\n ingrese la marca  para buscar en el rubro \n");
   fflush(stdin);
   scanf("%s",nombreMarca);
   printf("\n en total hay %2.2f $ en el rubro %i y con la marca %s \n",precioRecursivo(lista,nombreRubro,marca))
   ///////////3
   printf("\n el articulo de menor precio en la lista es de : \n");
   mostrarUnArticulo(menorPrecio(lista));
   ////////////////////4
   printf("\n ingrese un rubro para pasar los articulos  a la pila \n");
   scanf("%i",&rubro):
   pila=listaAPila(lista,&pila,rubro) ;

   //////////5////////
   printf("\n ingrese una marca para contar cuantos articulos hay en la pila \n");
   fflush(stdin)
   scanf("%s",nombreMarca);
   printf("\n en total hay %i articulos cargados en la pila ",cuentaPila(&pila,nombreMarca));
   /////////6///
   printf("\n ingrese un precio para pasar de la pila a la fila los mayores a ese precio \n");
   scanf("%f",&precio);
   pilaAFila(&pila,&Fila,precio);
    return 0;
}

