#ifndef FILA_H_INCLUDED
#define FILA_H_INCLUDED
#include <stdio.h>
#include <stdlib.h>

typedef struct
     {
   char nombre[30];
    char tipo[30];
    char jugo_partido; /// ‘s’ o ‘n’ 
    int nro;
    int goles;
    int amarillas;
}Estad_Partido;


typedef Estad_Partido Telemento;

typedef struct nodoD
{
    Telemento dato;
    struct nodoD* ant;
    struct nodoD* sig;
}nodoD;


typedef struct {

    ///COMPLETAR
}Fila;

///funciones
void inicFila(Fila*);
nodoD* crearNodo(Telemento);
void poneFila(Fila*,Telemento);
Telemento sacaFila(Fila*);
int filaVacia(Fila);
Telemento frente(Fila);



#endif // FILA_H_INCLUDED
