#include "articulo.h"

stArticulo cargarUnArticulo(){
    stArticulo a;

    printf("\n Codigo...........................: ");
    scanf("%d",&a.codigo);
    printf("\n Rubro (1 a 4)....................: ");
    scanf("%d",&a.rubro);
    fflush(stdin);
    printf("\n Marca............................: ");
    gets(a.marca);
    fflush(stdin);
    printf("\n Modelo...........................: ");
    gets(a.modelo);
    fflush(stdin);
    printf("\n Precio...........................: ");
    scanf("%f",&a.precio);

    return a;
}

void strRubro(int rubro,char strR[30]){
    switch (rubro){
        case 1:
            strcpy(strR,"Televisores");
            break;
        case 2:
            strcpy(strR,"Lavarropas");
            break;
        case 3:
            strcpy(strR,"Cocinas");
            break;
        case 4:
            strcpy(strR,"Calefactores");
            break;
    }
}

void mostrarUnArticulo(stArticulo a){
    char strR[30];
    strRubro(a.rubro,strR);
    printf("\n Id..............................: %d",a.id);
    printf("\n Codigo..........................: %d",a.codigo);
    printf("\n Rubro...........................: %d - %s",a.rubro, strR);
    printf("\n Marca...........................: %s",a.marca);
    printf("\n Modelo..........................: %s",a.modelo);
    printf("\n Precio..........................: %.2f\n",a.precio);

    printf("______________________________________________________________");
}



///////////////////


///////////1////////////////////////////////////////////////////
nodoD *iniciaListaD(){     //inicio lista con NULL


return NULL;
}

/////
nodoD *creaNodoD(stArticulo datos){      //creo el nodo poniendo en NULL los punteros y cargando los datos
 nodoD *aux=(nodoD*)malloc(sizeof(nodoD));
 aux->datos=datos;
 aux->siguiente=NULL;
 aux->anterior=NULL;

 return aux;
}

/////////
nodoD *cargrListaD(nodoD *listaD,char  nombreA[20]){

    stArticulo aux;

    FILE* pArchivo=fopen(nombreArch,"rb");

    if(fread(&aux,sizeof(stPersona),1,pArchivo)>0){ //controlo que haya lectura y si no informo de error


         while(!feof(pArchivo)){
            nodoD  nuevoNodo=creaNodoD(aux);      //creo elnodo y agrego en orden
            listaD=agregarEnOrden(listaD,nuevoNodo);
         }
    }
    else{
        printf("\n Error alabrir archivo ");
    }


return listaD; //retorno lista doble


}
////////////////////////////////
nodoD *agregarPpio(nodoD *lista, nodoD *nuevoNodo){

     if(!listaD==NULL){
         listaD=nuevoNodo;

     }
    else{
        nuevoNodo->siguiente=lista;       //agrego al principio y redefino lista para devolver
        listaD=nuevoNodo;


    }

return listaD;

}



/////////////
nodoD * agregarEnOrden(nodoD * listaD, nodo * nuevoNodo) {
    if(listaD == NULL) {          //la lista es NULL
        listaD = nuevoNodo;
    }else {
        if(strcmp(nuevoNodo->dato.marca,listaD->dato.marca)<0){//// el valor a agregar es mas chico que el primero
            listaD = agregarPpio(listaD, nuevoNodo);
    } else {
        nodoD * ante = listaD;
        nodoD * seg = listaD->siguiente;
        while((seg != NULL) &&(strcmp(nuevoNodo->dato.marca,seg->dato.marca)>0)) {//avanzo hasta encontrar el lugar
            ante = seg;
            seg = seg->siguiente;
        }
            nuevoNodo->siguiente = seg; // hago los enganches con los punteros
            nuevoNodo->anterior=ante;
            seg->anterior=nuevoNodo;
            ante->siguiente = nuevoNodo;
        }
    }
return listaD;
}

///////////////2//////////////////

precioRecursivo(nodoD * lista,int rubro,char marca[20]){

 float total=0;
    if(lista!=null){ // si la lista no es nula entra
            if((rubro==lista->datos.rubro)&& (strcmp(lista->datos.marca,marca)==0))// coincide rubro y marca

                total=total+lista->datos.precio+precioRecursivo(lista->siguiente,rubro,marca); //sumo y vuelvo a llamar avanzando en la lista
            else{
                total=precioRecursivo(lista->siguiente,rubro,marca); //llamo sin sumar avanzando en la lista
            }
    }
      //me cai de la lista entonces vuelvo con los resultados e informo

return total;


}


////////////////////////

stArticulo menorPrecio(nodoD *litaD){

    menor=50000;        //pongo un valor grande para que el primer articulo cumpla la condicion
    stArticulo datos;
    nodoD *aux=lista;


    if( aux!=NULL){
            while(aux!=NULL){            //mientras la lista no sea nula la voy a recorrer
                if (aux->datos.precio<menor)     //si se cumple que el precio es el menor guardo los datos
                    datos=aux->datos;


                aux=aux->siguiente;     //avanzo en la lista
            }

    }

return datos;
}

/////////////////////////4///////////////////
Pila listaAPila(nodoD *listaD , Pila *pila,int rubro){


 nodoD *axu=lista;
 stArticulo datos;

  if(aux!=NULL){
    while(aux!=NULL){
        if(lista->datos.rubro==rubro){       //sise cumple que coinciden los rubros
            datos=lista->datos;
            ponePila(&pila,datos);         //paso los datos a la pila
        }
    }
  }
return pila;
}



//////////////5/////////////////
int cuentaPila(Pila *pila,char marca[20]){

    int cantidad=0;
    stArticulo datos;

    if(!pilaVacia(pila)){

        while(!pilaVacia(pila)){          //mientras la pila no este vacia
            if( strcmp(pila.marca,marca)==0)
                cantidad=1+cuentaPila(sacaPila(&pila,datos),marca);        //se cumple entonces avanzo en la pila y sumo
            else
                cantidad=cuentaPila(sacaPila(&pila,datos),marca); //avanzo en la pila sin sumar

         ponePila(&pila,datos);      //vuelvo a poner todos los datos en la pila cuando vuelvo de la recursividad
        }


    }


return cantidad;

}





///////////// 6 //////////////

void *pilaAFila(nodoD *pila,fila **Fila,float precio){

    stArticulo datos;
    if(!pilaVacia(pila)){          //con fila practique poco pero lo quise hacer recursivo
                                    // si se cumple la condicion avanzo en la pila sacando el valor y poniendolo en la fila
            if( pila.precio>precio){
                sacaPila(&pila,datos);
                datos=pila.datos;
                fila *nodoFila=creaNodoD(datos)
                (*Fila)=agregaFila(nodoFila);
                pilaAFila(&pila,(*Fila),precio);

            }
            else{
              sacaPila(&pila,aux)  //si no se cumple la condicion avanzo en la pila recursivamente y a la vuelta pongo el valor  de nuevo en la pila
              pilaAFila(&pila,(*Fila),precio);
               ponePila(&pila,datos);

            }
        }
}
//////////////////////////////
