package render;

import distribuidora.liquidacion.empleado.Empleado;
import distribuidora.liquidacion.empleado.Repartidor;
import distribuidora.liquidacion.empleado.Vendedor;
import distribuidora.liquidacion.excepciones.ValorNumericoIncorrectoException;
import distribuidora.liquidacion.impresora.Impresora;
import distribuidora.liquidacion.impresora.ImpresoraRecibo;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import java.awt.*;
import java.io.IOException;
import java.text.NumberFormat;
import java.util.List;

public class RenderEmpleado extends JPanel implements ListCellRenderer<Empleado> {
    private final JCheckBox checkSeleccionado = new JCheckBox();
    private final JLabel labelLegajo = new JLabel();
    private final JTextField textFieldNombre = new JTextField();
    private final JFormattedTextField textFieldSueldo = new JFormattedTextField(NumberFormat.getCurrencyInstance());
    private final JFormattedTextField textFieldVentas = new JFormattedTextField(NumberFormat.getCurrencyInstance());
    private final JFormattedTextField textFieldKilometros = new JFormattedTextField(NumberFormat.getNumberInstance());
    private final JLabel labelAdicional = new JLabel("Adicional", SwingConstants.RIGHT);
    private final JButton buttonActualizarEmpleado = new JButton("Actualizar");
    private final JButton buttonImprimirRecibo = new JButton("Imprimir");
    private final JButton buttonEliminarEmpleado = new JButton("Eliminar");
    private final JButton buttonSalirPanelEmpleado = new JButton("Salir");
    private Empleado empleado;
    private boolean opcionSalirHabilitada = true;

    public RenderEmpleado() {
        createUIComponents();
        limpiarPanelEmpleado();
    }

    /**
     * Muestra el legajo, el nombre completo, el adicional y el sueldo total de un empleado.
     * <p>
     * Menú con 3 opciones:
     * <p>
     * 1. Actualizar: Si hubo cambios en el nombre o en el adicional, se guardan.
     * <p>
     * 2. Eliminar: Elimina al empleado del sistema. Limpia la pantalla.
     * <p>
     * 3. Salir: Limpia la pantalla. Elimina la referencia al empleado renderizado.
     *
     * @param empleado Información del empleado a mostrar
     */
    public void mostrarDetalleEmpleado(Empleado empleado) {
        this.empleado = empleado;
        limpiarPanelEmpleado();
        mostrarDetalleEmpleado();
        mostrarBotonera();
    }

    /**
     * Agrega los listeners a los botones y los habilita
     */
    private void mostrarBotonera() {
        this.buttonActualizarEmpleado.addActionListener(e -> {
            try {
                actualizarEmpleado();
                mostrarResultado("Datos actualizados.");
                mostrarDetalleEmpleado();
            } catch (ValorNumericoIncorrectoException exception) {
                ejecutarError(exception);
            }
        });

        this.buttonImprimirRecibo.addActionListener(e -> {
            Impresora impresora = new ImpresoraRecibo();
            try {
                impresora.imprimir(List.of(empleado));
            } catch (IOException exception) {
                ejecutarError(exception);
            }
        });

        this.buttonEliminarEmpleado.addActionListener(e -> {

        });

        this.buttonSalirPanelEmpleado.addActionListener(e -> {
            limpiarPanelEmpleado();
            this.empleado = null;
        });

        this.buttonActualizarEmpleado.setEnabled(true);
        this.buttonImprimirRecibo.setEnabled(true);
        this.buttonEliminarEmpleado.setEnabled(true);
        this.buttonSalirPanelEmpleado.setEnabled(this.opcionSalirHabilitada);
    }

    /**
     * Muestra el legajo, el nombre completo, el adicional y el sueldo total del empleado de referencia
     */
    private void mostrarDetalleEmpleado() {
        this.labelLegajo.setText(this.empleado.getLegajo());
        this.labelLegajo.setHorizontalAlignment(SwingConstants.RIGHT);
        this.textFieldNombre.setText(this.empleado.getNombre());
        this.textFieldSueldo.setValue(this.empleado.getSueldo());

        if (this.empleado.isVendedor()) {
            agregarInfoVendedor();
            this.textFieldVentas.setValue(((Vendedor) empleado).getVentas());
        } else if (this.empleado.isRepartidor()) {
            agregarInfoRepartidor();
            this.textFieldKilometros.setValue(((Repartidor) empleado).getKmRecorridos());
        }
        this.textFieldNombre.setEnabled(true);
    }

    /**
     * Guarda el nombre completo y actualiza la información adicional del empleado
     *
     * @throws ValorNumericoIncorrectoException El valor ingresado del adicional no se puede convertir a un número
     */
    private void actualizarEmpleado() throws ValorNumericoIncorrectoException {
        this.empleado.setNombre(this.textFieldNombre.getText());

        if (this.empleado.isVendedor()) {
            Object value = this.textFieldVentas.getValue();
            try {
                float ventas = Float.parseFloat(value.toString());
                ((Vendedor) empleado).setVentas(ventas);
            } catch (NumberFormatException exception) {
                throw new ValorNumericoIncorrectoException(value);
            }
        } else if (this.empleado.isRepartidor()) {
            Object value = this.textFieldKilometros.getValue();
            try {
                float kilometros = Float.parseFloat(value.toString());
                ((Repartidor) empleado).setKmRecorridos(kilometros);
            } catch (NumberFormatException exception) {
                throw new ValorNumericoIncorrectoException(value);
            }
        }
    }

    /**
     * Limpia la pantalla y deshabilita la botonera
     */
    private void limpiarPanelEmpleado() {
        this.labelLegajo.setText(null);
        this.textFieldNombre.setText(null);
        this.textFieldNombre.setEnabled(false);
        this.textFieldSueldo.setValue(null);
        this.buttonActualizarEmpleado.setEnabled(false);
        this.buttonImprimirRecibo.setEnabled(false);
        this.buttonEliminarEmpleado.setEnabled(false);
        this.buttonSalirPanelEmpleado.setEnabled(false);
        eliminarInfoAdicional();
    }

    /**
     * Agrega el componente visual correspondiente para mostrar el adicional del vendedor
     */
    private void agregarInfoVendedor() {
        GridBagConstraints gbc = getConstraints();
        gbc.gridwidth = 2;

        // Agregar en la tercer fila
        gbc.gridx = 0;
        gbc.gridy = 2;
        this.labelAdicional.setText("Ventas mensuales");
        this.labelAdicional.setVisible(true);
        this.add(this.labelAdicional, gbc);

        gbc.gridx = 2;
        gbc.gridy = 2;
        this.textFieldVentas.setVisible(true);
        this.add(this.textFieldVentas, gbc);
    }

    /**
     * Agrega el componente visual correspondiente para mostrar el adicional del repartidor
     */
    private void agregarInfoRepartidor() {
        GridBagConstraints gbc = getConstraints();
        gbc.gridwidth = 2;

        // Agregar en la tercer fila
        gbc.gridx = 0;
        gbc.gridy = 2; // Fila 3
        this.labelAdicional.setText("Kilómetros");
        this.labelAdicional.setVisible(true);
        this.add(this.labelAdicional, gbc);

        gbc.gridx = 2;
        gbc.gridy = 2; // Fila 3
        this.textFieldKilometros.setVisible(true);
        this.add(this.textFieldKilometros, gbc);
    }

    /**
     * Elimina solamente la parte de información adicional
     */
    private void eliminarInfoAdicional() {
        this.labelAdicional.setText(null);
        this.labelAdicional.setVisible(false);
        this.textFieldVentas.setValue(null);
        this.textFieldVentas.setVisible(false);
        this.textFieldKilometros.setValue(null);
        this.textFieldKilometros.setVisible(false);
    }

    /**
     * Muestra una alerta de error con el mensaje de la excepción
     *
     * @param exception Error ocurrido
     */
    private void ejecutarError(Exception exception) {
        JOptionPane.showMessageDialog(this, exception.getMessage());
    }

    /**
     * Muestra un mensaje de alerta con el toString del objeto
     *
     * @param object Objeto a mostrar en formato String
     */
    private void mostrarResultado(Object object) {
        JOptionPane.showMessageDialog(this, object, "Resultado", JOptionPane.INFORMATION_MESSAGE);
    }

    /**
     * Es el init del componente llamado automáticamente por Swing
     */
    private void createUIComponents() {
        this.setBorder(new EmptyBorder(50, 50, 50, 50));  // márgenes de 50 píxeles en todos los lados
        this.setBorder(new LineBorder(Color.BLACK, 1, true));
        this.setLayout(new GridBagLayout());
        GridBagConstraints gbc = getConstraints();
        gbc.gridwidth = 2;

        gbc.gridx = 0;
        gbc.gridy = 0;
        this.add(new JLabel("Legajo", SwingConstants.RIGHT), gbc);

        gbc.gridx = 2;
        gbc.gridy = 0;
        this.add(labelLegajo, gbc);

        // Repetir para la segunda fila
        gbc.gridx = 0;
        gbc.gridy = 1;
        this.add(new JLabel("Nombre", SwingConstants.RIGHT), gbc);

        gbc.gridx = 2;
        gbc.gridy = 1;
        gbc.gridwidth = 2;
        this.add(textFieldNombre, gbc);

        // Repetir para la cuarta fila
        gbc.gridx = 0;
        gbc.gridy = 3;
        this.add(new JLabel("Sueldo", SwingConstants.RIGHT), gbc);

        gbc.gridx = 2;
        gbc.gridy = 3;
        this.textFieldSueldo.setEnabled(false);
        this.add(textFieldSueldo, gbc);

        // Última fila con 3 componentes
        gbc.gridwidth = 1;
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.NONE;

        gbc.gridx = 0;
        gbc.gridy = 4;
        this.add(buttonActualizarEmpleado, gbc);

        gbc.gridx = 1;
        gbc.gridy = 4;
        this.add(buttonImprimirRecibo, gbc);

        gbc.gridx = 2;
        gbc.gridy = 4;
        this.add(buttonEliminarEmpleado, gbc);

        gbc.gridx = 3;
        gbc.gridy = 4;
        this.add(buttonSalirPanelEmpleado, gbc);

        this.setVisible(true);
    }

    private GridBagConstraints getConstraints() {
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.gridheight = 1;
        gbc.insets = new Insets(8, 8, 8, 8);
        return gbc;
    }

    @Override
    public Component getListCellRendererComponent(JList<? extends Empleado> list, Empleado value, int index, boolean isSelected,
                                                  boolean cellHasFocus) {
        this.opcionSalirHabilitada = false;
        mostrarDetalleEmpleado(value);
        return this;
    }
}
