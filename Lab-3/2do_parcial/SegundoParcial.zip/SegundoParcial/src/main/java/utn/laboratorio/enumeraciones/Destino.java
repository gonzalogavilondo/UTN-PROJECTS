package utn.laboratorio.enumeraciones;

public enum Destino {
    BUENOS_AIRES("Argentina", "Buenos Aires", TipoVuelo.NACIONAL, Aeropuerto.AEROPARQUE),
    CORDOBA("Argentina", "Córdoba", TipoVuelo.NACIONAL, Aeropuerto.CORDOBA),
    NEW_YORK("Estados Unidos", "New York", TipoVuelo.INTERNACIONAL, Aeropuerto.JFK),
    LOS_ANGELES("Estados Unidos", "Los Angeles", TipoVuelo.INTERNACIONAL, Aeropuerto.LAX),
    LONDRES("Reino Unido", "Londres", TipoVuelo.INTERNACIONAL, Aeropuerto.HEATHROW),
    MAR_DEL_PLATA("Argentina", "Mar del Plata", TipoVuelo.NACIONAL, Aeropuerto.MAR_DEL_PLATA);

    private final String pais;
    private final String ciudad;
    private final TipoVuelo tipoVuelo;
    private final Aeropuerto aeropuerto;

    Destino(String pais, String ciudad, TipoVuelo tipoVuelo, Aeropuerto aeropuerto) {
        this.pais = pais;
        this.ciudad = ciudad;
        this.tipoVuelo = tipoVuelo;
        this.aeropuerto = aeropuerto;
    }

    public String getPais() {
        return pais;
    }

    public String getCiudad() {
        return ciudad;
    }

    public TipoVuelo getTipoVuelo() {
        return tipoVuelo;
    }

    public Aeropuerto getAeropuerto() {
        return aeropuerto;
    }

    @Override
    public String toString() {
        return """
                                     
                Pais: %s,
                Ciudad: %s,
                Tipo de vuelo: %s
                Aeropuerto: %s""".formatted(pais, ciudad, tipoVuelo, aeropuerto);
    }
}
