package distribuidora.liquidacion.impresora;

import com.itextpdf.forms.PdfAcroForm;
import com.itextpdf.kernel.pdf.PdfDocument;
import com.itextpdf.kernel.pdf.PdfReader;
import com.itextpdf.kernel.pdf.PdfWriter;
import distribuidora.liquidacion.empleado.Empleado;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.List;
import java.util.logging.Level;

public class ImpresoraRecibo extends Impresora {

    @Override
    public String imprimir(List<Empleado> empleados) throws IOException {
        return imprimir(empleados, DEFAULT_PATH);
    }

    @Override
    public String imprimir(List<Empleado> empleados, String path) throws IOException {
        for (Empleado empleado : empleados) {
            String name = STR."\{path}\{empleado.getNombre()}\{DEFAULT_FILENAME}\{PDF_EXTENSION}";
            logger.log(Level.INFO, name);

            try {
                // Cargar el documento PDF existente
                PdfReader reader = new PdfReader(TEMPLATE_PATH_RECIBO);
                PdfWriter writer = new PdfWriter(name);
                PdfDocument pdfDoc = new PdfDocument(reader, writer);

                // Obtener el formulario del PDF
                PdfAcroForm form = PdfAcroForm.getAcroForm(pdfDoc, true);

                /*
                 * El formulario PDF no devuelve las key con el identificador que se le dio
                 * Por eso se usan los nombres que devuelve PdfAcroForm (a prueba y error)
                 */
                // TODO Crear el formulario PDF correctamente o usar un excel como template
                form.getField("dhFormfield-4958769698").setValue(empleado.getLegajo()); // Legajo
                form.getField("dhFormfield-4958770752").setValue(empleado.getNombre()); // Nombre
                form.getField("dhFormfield-4958771737").setValue(getFecha()); // Fecha
                form.getField("dhFormfield-4958771422").setValue(getPeriodo()); // Periodo

                // Hacer los campos no editables si es necesario
                form.flattenFields();

                // Cerrar el documento
                pdfDoc.close();
            } catch (FileNotFoundException e) {
                logger.log(Level.SEVERE, e.getMessage(), e);
            }
        }
        return path;
    }

    @Override
    public List<Empleado> leer(String path) throws IOException {
        return null;
    }
}
