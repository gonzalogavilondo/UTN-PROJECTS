package distribuidora.liquidacion.empleado;

public interface Supervisable {
    void supervisar(Supervisor supervisor);

    void liberar();
}
