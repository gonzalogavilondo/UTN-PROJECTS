package utn.laboratorio.enumeraciones;

public enum Aeropuerto {
    CORDOBA("Córdoba"),
    AEROPARQUE("Aeroparque Jorge Newbery"),
    JFK("John F. Kennedy"),
    LAX("Los Angeles International"),
    HEATHROW("Heathrow"),
    MAR_DEL_PLATA("Astor Piazzolla");

    private final String nombre;

    Aeropuerto(String nombre) {
        this.nombre = nombre;
    }

    public String getNombre() {
        return nombre;
    }
}
