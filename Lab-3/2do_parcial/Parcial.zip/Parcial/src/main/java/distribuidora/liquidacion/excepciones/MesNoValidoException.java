package distribuidora.liquidacion.excepciones;

public class MesNoValidoException extends Exception {
    private int mes;

    public MesNoValidoException(int mes) {
        super(STR."No se puede procesar el mes \{mes}.");
    }

    public int getMes() {
        return mes;
    }
}
