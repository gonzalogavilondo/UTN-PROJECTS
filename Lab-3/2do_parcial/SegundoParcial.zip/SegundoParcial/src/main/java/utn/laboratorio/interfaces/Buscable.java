package utn.laboratorio.interfaces;

/*
    TODO 1: Implementar la interfaz Buscable<C> que permita buscar elementos que cumplan con un criterio de búsqueda.
     La interfaz debe tener el método matches que recibe un criterio de búsqueda y devuelve true si el elemento cumple con el criterio.
     (5 puntos)
 */
public interface Buscable {
}