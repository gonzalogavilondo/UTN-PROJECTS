package distribuidora.liquidacion.configuracion;

import distribuidora.liquidacion.excepciones.MesNoValidoException;

public enum Mes {
    ENERO(1, "Enero"),
    FEBRERO(2, "Febrero"),
    MARZO(3, "Marzo"),
    ABRIL(4, "Abril"),
    MAYO(5, "Mayo"),
    JUNIO(6, "Junio"),
    JULIO(7, "Julio"),
    AGOSTO(8, "Agosto"),
    SEPTIEMBRE(9, "Septiembre"),
    OCTUBRE(10, "Octubre"),
    NOVIEMBRE(11, "Noviembre"),
    DICIEMBRE(12, "Diciembre");

    private final int mes;
    private final String nombre;

    Mes(int mes, String nombre) {
        this.mes = mes;
        this.nombre = nombre;
    }

    public int getMes() {
        return mes;
    }

    public String getNombre() {
        return nombre;
    }

    public Mes valueOf(int mes) throws MesNoValidoException {
        return switch (mes) {
            case 1 -> ENERO;
            case 2 -> FEBRERO;
            case 3 -> MARZO;
            case 4 -> ABRIL;
            case 5 -> MAYO;
            case 6 -> JUNIO;
            case 7 -> JULIO;
            case 8 -> AGOSTO;
            case 9 -> SEPTIEMBRE;
            case 10 -> OCTUBRE;
            case 11 -> NOVIEMBRE;
            case 12 -> DICIEMBRE;
            default -> throw new MesNoValidoException(mes);
        };
    }
}
