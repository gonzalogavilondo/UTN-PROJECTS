package utn.laboratorio;

import utn.laboratorio.entidades.Vuelo;
import utn.laboratorio.enumeraciones.Destino;
import utn.laboratorio.enumeraciones.EstadoVuelo;

import javax.swing.*;

public class DetalleVuelo extends JDialog {
    private final Vuelo vuelo;
    private JPanel contentPane;
    private JButton botonReservar;
    private JLabel numeroVuelo;
    private JComboBox<Destino> comboOrigen;
    private JComboBox<Destino> comboDestino;
    private JLabel horarioSalida;
    private JLabel horarioLlegada;
    private JComboBox<EstadoVuelo> comboEstadoVuelo;

    public DetalleVuelo(Vuelo vuelo) {
        this.vuelo = vuelo;
        setContentPane(contentPane);
        setModal(true);
        getRootPane().setDefaultButton(botonReservar);
        init();
    }

    private void init() {
        /*
            TODO 10: Completar el método init.
             El método debe completar los campos del formulario con los datos del vuelo recibido como parámetro.
             Por ejemplo, el campo numeroVuelo debe mostrar el código del vuelo.
             numeroVuelo.setText(vuelo.getCodigoVuelo());
             Para completar los campos de los combos, se puede utilizar el método setSelectedItem.
             Campos a completar: numeroVuelo, comboOrigen, comboDestino, horarioSalida, horarioLlegada, comboEstadoVuelo.
             (3 puntos)
         */

        botonReservar.addActionListener(e -> {
            DialogReservaVuelo dialogReservaVuelo = new DialogReservaVuelo(this.vuelo);
            dialogReservaVuelo.setVisible(true);
        });
    }

    private void createUIComponents() {
        comboOrigen = new JComboBox<>(Destino.values());
        comboDestino = new JComboBox<>(Destino.values());
        comboEstadoVuelo = new JComboBox<>(EstadoVuelo.values());
    }
}
