package distribuidora.liquidacion.menu;

public interface Menu {
    void ejecutarMenuPrincipal();
}
