package utn.laboratorio.enumeraciones;

public enum EstadoReserva {
    PENDIENTE, CONFIRMADA, CANCELADA
}
