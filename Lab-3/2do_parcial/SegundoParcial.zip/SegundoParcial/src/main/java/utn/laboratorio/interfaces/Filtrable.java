package utn.laboratorio.interfaces;

/*
    TODO 2: Implementar la interfaz Filtrable<F> que permita filtrar elementos que cumplan con un criterio de filtrado.
     La interfaz debe tener el método filter que recibe un criterio de filtrado y devuelve true si el elemento cumple con el criterio.
     (5 puntos)
 */
public interface Filtrable {
}
